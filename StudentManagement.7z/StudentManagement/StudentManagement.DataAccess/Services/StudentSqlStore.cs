﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using StudentManagement.DataAccess.Models;

namespace StudentManagement.DataAccess.Services
{
    public class StudentSqlStore : Interfaces.IStore,IDisposable
    {
        private Interfaces.IDbConfiguration _dbConfiguration;
        private MySqlConnection _mySqlConnection;
        private MySqlCommand _mySqlCommand;
        private string _connection;


        public StudentSqlStore(Interfaces.IDbConfiguration configuration)
        {
            _dbConfiguration = configuration;
            _connection = _dbConfiguration.GetConnectionConfiguration();
        }



        public async Task<string> Add(Student student)
        {
            var response = "";
            using (_mySqlConnection = new MySqlConnection(_connection))
            using (_mySqlCommand = _mySqlConnection.CreateCommand())
            {
                _mySqlCommand.CommandText = "call addStudent(?id,?name,?class)";
                _mySqlCommand.Parameters.Add(new MySqlParameter("id", student.Id));
                _mySqlCommand.Parameters.Add(new MySqlParameter("name", student.Name));
                _mySqlCommand.Parameters.Add(new MySqlParameter("class", student.Class));
                try
                {
                    ConnectionFactory.GetConnectionOpen(_mySqlConnection);
                    response = await _mySqlCommand.ExecuteNonQueryAsync() > 0 ? "inserted" : "could not insert the record";
                }
                catch (Exception e)
                {
                    response= e.Message;
                }
            }
            return response;
        }

        public void Dispose()
        {
            _mySqlConnection.CloseAsync();
        }

        public async Task<List<Student>> Get()
        {
            var response = new List<Student>();
            using (_mySqlConnection = new MySqlConnection(_connection))
            using (_mySqlCommand = _mySqlConnection.CreateCommand())
            {
                _mySqlCommand.CommandText = "call getStudents()";
                try
                {
                    ConnectionFactory.GetConnectionOpen(_mySqlConnection);
                    var reader = await _mySqlCommand.ExecuteReaderAsync();
                    if (reader.HasRows)
                    {
                        while (await reader.ReadAsync())
                        {

                            var student = new Student()
                            {
                                Id = Convert.ToInt32(reader[0].ToString()),
                                Name = reader[1].ToString(),
                                Class = reader[2].ToString()

                            };
                            response.Add(student);
                        }
                    }
                }
                catch (Exception e)
                {
                    throw new Exception(e.Message);
                }
            }
            return response;
        }

        public async Task<Student> GetById(object student)
        {
            var response = new Student();
            using (_mySqlConnection = new MySqlConnection(_connection))
            using (_mySqlCommand = _mySqlConnection.CreateCommand())
            {
                _mySqlCommand.CommandText = "call getStudents()";
                try
                {
                    ConnectionFactory.GetConnectionOpen(_mySqlConnection);
                    var reader = await _mySqlCommand.ExecuteReaderAsync();
                    if (reader.HasRows)
                    {
                        await reader.ReadAsync();
                        response.Id = Convert.ToInt32(reader[0].ToString());
                        response.Name = reader[1].ToString();
                        response.Class = reader[2].ToString();
                    }
                }
                catch (Exception e)
                {
                    throw new Exception(e.Message);
                }
            }
            return response;
        }
    }
}
