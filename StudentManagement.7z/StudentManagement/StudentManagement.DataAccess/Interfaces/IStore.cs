﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using StudentManagement.DataAccess.Models;

namespace StudentManagement.DataAccess.Interfaces
{
    public interface IStore
    {
        Task<string> Add(Student student);
        Task<Student> GetById(int id);
        Task<List<Student>> Get();
      
    }
}
