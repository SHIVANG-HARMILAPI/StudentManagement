﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Text;

namespace StudentManagement.DataAccess.Services
{
    public class StudentSqlDbConfiguration : Interfaces.IDbConfiguration
    {
        private IConfiguration _configuration;

        public StudentSqlDbConfiguration(IConfiguration configuration)
        {
            _configuration = configuration;
        }
       
        public string GetConnectionConfiguration()
        {
            return _configuration.GetSection("connection").Value;
        }
    }
}
