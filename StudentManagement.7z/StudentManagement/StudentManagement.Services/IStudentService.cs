﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using StudentManagement.DataAccess.Models;

namespace StudentManagement.Services
{
    public interface IStudentService
    {
        Task<List<Student>> GetStudents();
        Task<Student> GetStudent(int id);
        Task<string> AddStudent(Student student);
        Task<string> AddStudentByUrl(Uri url);
    }
}
