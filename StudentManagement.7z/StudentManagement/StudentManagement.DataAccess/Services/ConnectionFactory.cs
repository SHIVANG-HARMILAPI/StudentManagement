﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using MySql.Data.MySqlClient;

namespace StudentManagement.DataAccess.Services
{
    public class ConnectionFactory
    {
        public static MySqlConnection GetConnectionOpen(MySqlConnection connection)
        {
            if (connection.State == ConnectionState.Open)
            {
                return connection;
            }
            else
            {
                connection.OpenAsync();
                return connection;
            }
        }
    }
}
