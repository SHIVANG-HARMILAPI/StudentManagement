﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using StudentManagement.DataAccess.Models;
using StudentManagement.Services;

namespace StudentManagement.Web.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StudentController : ControllerBase
    {
        private IStudentService _studentService;

        public StudentController(IStudentService studentService)
        {
            _studentService = studentService;
        }
        [HttpGet("Get")]
        public async Task<IActionResult> Get()
        {
            var response = await _studentService.GetStudents();
            return Ok(response);    
        }

        [HttpGet("GetById")]
        public async Task<IActionResult> Get([FromQuery]int id)
        {
            var response = await _studentService.GetStudent(id);
            return Ok(response);
        }

        [HttpPost("Add")]
        public async Task<IActionResult> Post([FromBody] Student student)
        {
            var response = await _studentService.AddStudent(student);
            return Ok(response);
        }

        [HttpPost("AddByUrl")]
        public async Task<IActionResult> Post([FromQuery] Uri url)
        {
            var response = await _studentService.AddStudentByUrl(url);
            return Ok(response);
        }


    }
}
