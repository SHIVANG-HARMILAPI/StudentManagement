﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using StudentManagement.DataAccess.Interfaces;
using StudentManagement.DataAccess.Models;
using Newtonsoft.Json;
namespace StudentManagement.Services
{
    public class StudentService : IStudentService
    {
        private IStore _dbStore;

        public StudentService(IStore dbStore)
        {
            _dbStore = dbStore;
        }

        public async Task<string> AddStudent(Student student)
        {
            var response = await _dbStore.Add(student);
            return response;

        }
            public async Task<string> AddStudentByUrl(Uri url)
            {
                return "";
            }

            public async Task<Student> GetStudent(int id)
            {
                var response = await _dbStore.GetById(id);
                return response;
            }

            public async Task<List<Student>> GetStudents()
            {
                var response = await _dbStore.Get();
                return response;
            }
        }

    
}
